package com.agung.camera;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.os.Build;
import androidx.core.content.FileProvider;
import java.io.File;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends AppCompatActivity {
	
	public final int REQ_CD_CAM = 101;
	
	private FloatingActionButton _fab;
	private String errorShort = "";
	private String errorLong = "";
	
	private LinearLayout linear1;
	
	private Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
	private File _file_cam;
	private Intent view = new Intent();
	private AlertDialog.Builder error;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_fab = findViewById(R.id._fab);
		
		linear1 = findViewById(R.id.linear1);
		_file_cam = FileUtil.createNewPictureFile(getApplicationContext());
		Uri _uri_cam;
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
			_uri_cam = FileProvider.getUriForFile(getApplicationContext(), getApplicationContext().getPackageName() + ".provider", _file_cam);
		} else {
			_uri_cam = Uri.fromFile(_file_cam);
		}
		cam.putExtra(MediaStore.EXTRA_OUTPUT, _uri_cam);
		cam.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
		error = new AlertDialog.Builder(this);
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				try {
					mCamera.takePicture(null, null, mPicture);
				} catch (Exception e) {
					errorShort = e.getMessage().toString();
					errorLong = e.toString();
					_trigger_error(errorShort, errorLong);
				}
				android.hardware.camera2.CameraManager cameraManager = (android.hardware.camera2.CameraManager) getSystemService(Context.CAMERA_SERVICE);
				try {
					String cameraId = cameraManager.getCameraIdList()[0]; cameraManager.setTorchMode(cameraId, true); } catch (android.hardware.camera2.CameraAccessException e) { }
			}
		});
	}
	
	private void initializeLogic() {
		_detect();
		_access();
		FrameLayout camera_preview = new FrameLayout(this);
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
		camera_preview.setLayoutParams(lp);
		linear1.addView(camera_preview);
		//linear1.removeView(button1);
		//linear1.removeView(imageview1);
		//camera_preview.addView(button1);
		//f.addView(imageview1);
		// Create an instance of Camera
		mCamera = getCameraInstance();
		// Create our Preview view and set it as the content of our activity
		mPreview = new CameraPreview(this, mCamera);
		//camera_preview is the name of our FrameLayout
		camera_preview.addView(mPreview);
		android.hardware.camera2.CameraManager cameraManager = (android.hardware.camera2.CameraManager) getSystemService(Context.CAMERA_SERVICE);
		try {
			String cameraId = cameraManager.getCameraIdList()[0]; cameraManager.setTorchMode(cameraId, true); } catch (android.hardware.camera2.CameraAccessException e) { }
	}
	
	@Override
	public void onPause() {
		super.onPause();
		releaseCamera();
		finish();
	}
	
	@Override
	public void onResume() {
		super.onResume();
		/*try {
if (mCamera = null){
//if Camera has been released then we will create it again - work in progress
mCamera = getCameraInstance();
}
} catch (Exception e) {
errorShort = e.getMessage().toString();
errorLong = e.toString();
_trigger_error(errorShort, errorLong);
}*/
	}
	public void _detect() {
	}
	/** Check if this device has a camera */
	private boolean checkCameraHardware(Context context) {
		    if (context.getPackageManager().hasSystemFeature(android.content.pm.PackageManager.FEATURE_CAMERA)){
			        // this device has a camera
			        
			SketchwareUtil.showMessage(getApplicationContext(), "This device has a camera");
			return true;
			    } else {
			        // no camera on this device
			        
			SketchwareUtil.showMessage(getApplicationContext(), "No camera on this device");
			return false;
			    }
		
	}
	
	
	public void _access() {
		/** A safe way to get an instance of the Camera object. */
		
	}
	public static android.hardware.Camera getCameraInstance(){
		    android.hardware.Camera c = null;
		    try {
			        c = android.hardware.Camera.open(); 
			
			// attempt to get a Camera instance
			    }
		    catch (Exception e){
			
			        // Camera is not available (in use or does not exist)
			    }
		    
		return c; // returns null if camera is unavailable
		
	}
	
	
	public void _preview() {
	}
	/** A basic Camera preview class */
	public class CameraPreview extends android.view.SurfaceView implements SurfaceHolder.Callback {
		    private android.view.SurfaceHolder mHolder;
		    private android.hardware.Camera mCamera;
		
		    public CameraPreview(Context context, android.hardware.Camera camera) {
			        super(context);
			        mCamera = camera;
			
			        // Install a SurfaceHolder.Callback so we get notified when the
			        // underlying surface is created and destroyed.
			        mHolder = getHolder();
			        mHolder.addCallback(this);
			        // deprecated setting, but required on Android versions prior to 3.0
			        mHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
			    }
		
		    public void surfaceCreated(SurfaceHolder holder) {
			        // The Surface has been created, now tell the camera where to draw the preview.
			        try {
				            mCamera.setPreviewDisplay(holder);
				            mCamera.startPreview();
				        } catch (Exception e) {
				            
				        }
			    }
		
		    public void surfaceDestroyed(SurfaceHolder holder) {
			        // empty. Take care of releasing the Camera preview in your activity.
			    }
		
		    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
			        // If your preview can change or rotate, take care of those events here.
			        // Make sure to stop the preview before resizing or reformatting it.
			
			        if (mHolder.getSurface() == null){
				          // preview surface does not exist
				          return;
				        }
			
			        // stop preview before making changes
			        try {
				            mCamera.stopPreview();
				        } catch (Exception e){
				          // ignore: tried to stop a non-existent preview
				        }
			
			        // set preview size and make any resize, rotate or
			        // reformatting changes here
			
			        // start preview with new settings
			        try {
				            mCamera.setPreviewDisplay(mHolder);
				            mCamera.startPreview();
				
				        } catch (Exception e){
				            
				        }
			    }
		
	}
	
	
	public void _init() {
	}
	
	    private android.hardware.Camera mCamera;
	    private CameraPreview mPreview;
	{
	}
	
	
	public void _capture() {
	}
	
	final android.hardware.Camera.PictureCallback mPicture = new android.hardware.Camera.PictureCallback() {
		
		    @Override
		    public void onPictureTaken(byte[] data, android.hardware.Camera camera) {
			
			        File pictureFile = getOutputMediaFile(android.provider.MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE);
			        if (pictureFile == null){
				            //storage perms
				            return;
				        }
			
			        try {
				            java.io.FileOutputStream fos = new java.io.FileOutputStream(pictureFile);
				            fos.write(data);
				            fos.close();
				        } catch (Exception e) {
				            //Log.d(TAG, "File not found: " + e.getMessage());
				        } 
			    }
	};
	{
	}
	
	
	public void _save() {
	}
	public static final int MEDIA_TYPE_IMAGE = 1;
	public static final int MEDIA_TYPE_VIDEO = 2;
	
	/** Create a file Uri for saving an image or video */
	private static Uri getOutputMediaFileUri(int type){
		      return Uri.fromFile(getOutputMediaFile(type));
	}
	
	/** Create a File for saving an image or video */
	private static File getOutputMediaFile(int type){
		    // To be safe, you should check that the SDCard is mounted
		    // using Environment.getExternalStorageState() before doing this.
		
		    File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(
		              Environment.DIRECTORY_DCIM), "Camera");
		    // This location works best if you want the created images to be shared
		    // between applications and persist after your app has been uninstalled.
		
		    // Create the storage directory if it does not exist
		    if (! mediaStorageDir.exists()){
			        if (! mediaStorageDir.mkdirs()){
				            //Log.d("OpenCam", "failed to create directory");
				            return null;
				        }
			    }
		
		    // Create a media file name
		    String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
		    File mediaFile;
		    if (type == MEDIA_TYPE_IMAGE){
			        mediaFile = new File(mediaStorageDir.getPath() + File.separator +
			        "IMG_"+ timeStamp + ".jpg");
			    } else if(type == MEDIA_TYPE_VIDEO) {
			        mediaFile = new File(mediaStorageDir.getPath() + File.separator +
			        "VID_"+ timeStamp + ".mp4");
			    } else {
			        return null;
			    }
		
		    return mediaFile;
		
		
		// Abhinandan
	}
	
	
	public void _release() {
	}
	private void releaseCamera(){
		        if (mCamera != null){
			            mCamera.release();        // release the camera for other applications
			            mCamera = null;
			        }
		
	}
	
	
	public void _takePic() {
	}
	public final void takePicture(android.hardware.Camera.ShutterCallback shutter, android.hardware.Camera.PictureCallback raw, android.hardware.Camera.PictureCallback jpeg)
	{
	}
	
	
	public void _trigger_error(final String _title, final String _message) {
		error.setTitle(_title);
		error.setMessage(_message);
		error.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		error.create().show();
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}